class Hotel 
{
	
}