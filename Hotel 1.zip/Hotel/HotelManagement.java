import java.util.Scanner;

import javax.lang.model.util.ElementScanner14;
import javax.swing.text.PlainDocument;


class HotelManagement 
{
	Scanner sc=new Scanner(System.in);
	
   Hotel h= new Hotel();

	public void chooseFood()
	{
		System.out.println("1.veg 2.non veg");
		switch(sc.nextInt())
		{
			case 1:
				h=new Veg();
			break;
			case 2:
				h=new NonVeg();
			break;

		}

	}
	public void orderFood()
	{
         if(h instanceof Veg)
		 {
			 Veg v1=(Veg)h;
			  for(;;)
			 {
                System.out.println("Sr."+"          food name     "+"                   price ");
			    System.out.println("1."+"        "+v1.food1+"                            "+v1. price1);
			    System.out.println("2."+"        "+v1.food2+"                                "+v1. price2);
			    System.out.println("3."+"        "+v1.food3+"                                "+v1. price3);
			    System.out.println("4."+"        "+v1.food4+"                               "+v1. price4);
			    System.out.println("5."+"        "+v1.food5+"                          "+v1. price5);
			    System.out.println("6."+"        "+v1.food6+"                "+v1. price6);
			    System.out.println("7."+"        "+v1.food7+"                          "+v1. price7);
			    System.out.println("8."+"        "+v1.food8+"                             "+v1. price8);
			    System.out.println("9.          please bring food"+(char)2);
			switch(sc.nextInt())
		    {
				case 1:
					System.out.println("please enter qty");
				  v1.qty1=sc.nextInt();
					break;
				case 2:
					System.out.println("please enter qty");
				  v1.qty2=sc.nextInt();
					break;
				case 3:
					System.out.println("please enter qty");
				  v1.qty3=sc.nextInt();

					break;
				case 4:
					System.out.println("please enter qty");
				  v1.qty4=sc.nextInt();
					break;
				case 5:
					System.out.println("please enter qty");
				  v1.qty5=sc.nextInt();
					break;
				case 6:
					System.out.println("please enter qty");
				  v1.qty6=sc.nextInt();
					break;
				case 7:
					System.out.println("please enter qty");
				  v1.qty7=sc.nextInt();
					break;
				case 8:
					System.out.println("please enter qty");
				  v1.qty8=sc.nextInt();
					break;
				case 9:
					return ;
			}
			 }
		 }

         else if(h instanceof NonVeg)
		 {
			 NonVeg n1=(NonVeg)h;
			  for(;;)
			 {
                System.out.println("Sr."+"          food name     "+"                   price ");
			    System.out.println("1."+"        "+n1.food1+"                            "+n1. price1);
			    System.out.println("2."+"        "+n1.food2+"                                "+n1. price2);
			    System.out.println("3."+"        "+n1.food3+"                                "+n1. price3);
			    System.out.println("4."+"        "+n1.food4+"                               "+n1. price4);
			    System.out.println("5."+"        "+n1.food5+"                          "+n1. price5);
			    System.out.println("6."+"        "+n1.food6+"                "+n1. price6);
			    System.out.println("7."+"        "+n1.food7+"                          "+n1. price7);
			    System.out.println("8."+"        "+n1.food8+"                             "+n1. price8);
                System.out.println("9."+"        "+n1.food9+"                     "+n1. price9);
			    System.out.println("10."+"       "+n1.food10+"                       "+n1. price10);
                System.out.println("11."+"       "+n1.food11+"                       "+n1. price11);
			    System.out.println("12."+"       "+n1.food12+"                       "+n1. price12);
			    System.out.println("13.          please bring food"+(char)2);
			switch(sc.nextInt())
		    {
				case 1:
					System.out.println("please enter qty");
				  n1.qty1=sc.nextInt();
					break;
				case 2:
					System.out.println("please enter qty");
				  n1.qty2=sc.nextInt();
					break;
				case 3:
					System.out.println("please enter qty");
				  n1.qty3=sc.nextInt();

					break;
				case 4:
					System.out.println("please enter qty");
				  n1.qty4=sc.nextInt();
					break;
				case 5:
					System.out.println("please enter qty");
				  n1.qty5=sc.nextInt();
					break;
				case 6:
					System.out.println("please enter qty");
				  n1.qty6=sc.nextInt();
					break;
				case 7:
					System.out.println("please enter qty");
				  n1.qty7=sc.nextInt();
					break;
				case 8:
					System.out.println("please enter qty");
				  n1.qty8=sc.nextInt();
					break;
                    case 9:
					System.out.println("please enter qty");
				  n1.qty9=sc.nextInt();
					break;
				case 10:
					System.out.println("please enter qty");
				  n1.qty10=sc.nextInt();
					break;
                    case 11:
					System.out.println("please enter qty");
				  n1.qty11=sc.nextInt();
					break;
				case 12:
					System.out.println("please enter qty");
				  n1.qty12=sc.nextInt();
					break;
				case 13:
					return ;
			}
			 }
		 }
         else{
            System.out.println("First choose hotel");
         }
	}
	double sum=0;
	public void bill()
	{
		int c=1;
		
       // double s=sum;
		if(h instanceof Veg)
		{
          Veg v1=(Veg)h;
		  System.out.println("s.no"+"       food name        "+"  qty  "+"   price   ");
           if(v1.qty1!=0)
		   {
			   System.out.println(c++ +"      "+v1.food1+"                "+v1.qty1+"      "+(v1.qty1*v1.price1));
		       sum=sum+(v1.qty1*v1.price1);
		   }
			    if(v1.qty2!=0)
		   {
			   System.out.println(c++ +"      "+v1.food2+"                    "+v1.qty2+"      "+(v1.qty2*v1.price2));
		    sum=sum+(v1.qty2*v1.price2);
		   }
		    if(v1.qty3!=0)
		   {
			   System.out.println(c++ +"      "+v1.food3+"                    "+v1.qty3+"      "+(v1.qty3*v1.price3));
		        sum=sum+(v1.qty3*v1.price3);
		   }
			    if(v1.qty4!=0)
		   {
			   System.out.println(c++ +"      "+v1.food4+"                   "+v1.qty4+"      "+(v1.qty4*v1.price4));
		      sum=sum+(v1.qty4*v1.price4);
		   }
			    if(v1.qty5!=0)
		   {
			   System.out.println(c++ +"      "+v1.food5+"              "+v1.qty5+"      "+(v1.qty5*v1.price5));
		       sum=sum+(v1.qty5*v1.price5);
		   }
			    if(v1.qty6!=0)
		   {
			   System.out.println(c++ +"      "+v1.food6+"    "+v1.qty6+"      "+(v1.qty6*v1.price6));
		       sum=sum+(v1.qty6*v1.price6);
		   }
			    if(v1.qty7!=0)
		   { 
			   System.out.println(c++ +"      "+v1.food7+"              "+v1.qty7+"      "+(v1.qty7*v1.price7));
		       sum=sum+(v1.qty7*v1.price7);
		   }
			    if(v1.qty8!=0)
		   {
			   System.out.println(c++ +"      "+v1.food8+"                 "+v1.qty8+"      "+(v1.qty8*v1.price8));
		          sum=sum+(v1.qty8*v1.price8);
		   }
		   System.out.println("_____________________________________________________");
		   System.out.println("total                                 "+sum);
           payment();

		}

        else if(h instanceof NonVeg)
		{
        
          NonVeg n1=(NonVeg)h;
		  System.out.println("s.no"+"       food name        "+"  qty  "+"   price   ");
           if(n1.qty1!=0)
		   {
			   System.out.println(c++ +"      "+n1.food1+"                "+n1.qty1+"      "+(n1.qty1*n1.price1));
		       sum=sum+(n1.qty1*n1.price1);
		   }
			    if(n1.qty2!=0)
		   {
			   System.out.println(c++ +"      "+n1.food2+"                    "+n1.qty2+"      "+(n1.qty2*n1.price2));
		    sum=sum+(n1.qty2*n1.price2);
		   }
		    if(n1.qty3!=0)
		   {
			   System.out.println(c++ +"      "+n1.food3+"                    "+n1.qty3+"      "+(n1.qty3*n1.price3));
		        sum=sum+(n1.qty3*n1.price3);
		   }
			    if(n1.qty4!=0)
		   {
			   System.out.println(c++ +"      "+n1.food4+"                   "+n1.qty4+"      "+(n1.qty4*n1.price4));
		      sum=sum+(n1.qty4*n1.price4);
		   }
			    if(n1.qty5!=0)
		   {
			   System.out.println(c++ +"      "+n1.food5+"              "+n1.qty5+"      "+(n1.qty5*n1.price5));
		       sum=sum+(n1.qty5*n1.price5);
		   }
			    if(n1.qty6!=0)
		   {
			   System.out.println(c++ +"      "+n1.food6+"    "+n1.qty6+"      "+(n1.qty6*n1.price6));
		       sum=sum+(n1.qty6*n1.price6);
		   }
			    if(n1.qty7!=0)
		   { 
			   System.out.println(c++ +"      "+n1.food7+"              "+n1.qty7+"      "+(n1.qty7*n1.price7));
		       sum=sum+(n1.qty7*n1.price7);
		   }
			    if(n1.qty8!=0)
		   {
			   System.out.println(c++ +"      "+n1.food8+"                 "+n1.qty8+"      "+(n1.qty8*n1.price8));
		          sum=sum+(n1.qty8*n1.price8);
		   }
           if(n1.qty9!=0)
		   { 
			   System.out.println(c++ +"      "+n1.food9+"         "+n1.qty9+"      "+(n1.qty9*n1.price9));
		       sum=sum+(n1.qty9*n1.price9);
		   }
			    if(n1.qty10!=0)
		   {
			   System.out.println(c++ +"      "+n1.food10+"           "+n1.qty10+"      "+(n1.qty10*n1.price10));
		          sum=sum+(n1.qty10*n1.price10);
		   }
           if(n1.qty11!=0)
		   { 
			   System.out.println(c++ +"      "+n1.food11+"           "+n1.qty11+"      "+(n1.qty11*n1.price11));
		       sum=sum+(n1.qty11*n1.price11);
		   }
			    if(n1.qty12!=0)
		   {
			   System.out.println(c++ +"      "+n1.food12+"           "+n1.qty12+"      "+(n1.qty12*n1.price12));
		          sum=sum+(n1.qty12*n1.price12);
		   }
		   System.out.println("_____________________________________________________");
		   System.out.println("total                                 "+sum);
           payment();

		}
        else{
            System.out.println("First order the food");
        }
	}

    public void payment(){
        
        if(h instanceof Veg)
        {
            
           // Veg v2=new Veg();
            Veg v1=(Veg)h;
            System.out.println("Enter the money");
            double money=sc.nextDouble();
            if(money>=sum)
            {
                System.out.println("Your bill is successful paid");
				
				
            }
            else {
                System.out.println("Your bill is cancelled");
            }
			return;

        }
        else if(h instanceof NonVeg)
        {
           // NonVeg n2=new NonVeg();
            NonVeg n1=(NonVeg)h;
            System.out.println("Enter the money");
            double money=sc.nextDouble();
            if(money>=sum)
            {
                System.out.println("Your bill is successful paid");
				
            }
            else{
                System.out.println("Your bill is cancelled");
            }
			return;

        }
		else{
			System.out.println("order food first");

			/*if(h instanceof Veg || h instanceof NonVeg)
			{
				System.out.println("Enter the money");
				double money=sc.nextDouble();
				if(money>=sum)
				{
					System.out.println("Your bill is successful paid");
					return;
				
					
				}
				else {
					System.out.println("Your bill is cancelled");
				}
				
			}*/
		}
   }
}

