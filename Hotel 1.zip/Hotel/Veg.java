class Veg extends Hotel
{
	String food1="chapathi";
	String food2="naan";
	String food3="roti";
	String food4="papad";
	String food5="jeera rice";
	String food6="panner butter masala";
	String food7="aloo jeera";
	String food8="bislery";
	double price1=7;
	double price2=25;
	double price3=15;
	double price4=10;
	double price5=35;
	double price6=120;
	double price7=45;
	double price8=20;
	int qty1=0;
	int qty2=0;
	int qty3=0;
	int qty4=0;
	int qty5=0;
	int qty6=0;
	int qty7=0;
	int qty8=0;
	

	


}
